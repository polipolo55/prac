var searchData=
[
  ['main_0',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['missatges_1',['Missatges',['../class_missatges.html#a90900698bcfc3493073b6ce992adf4e9',1,'Missatges']]]
];
