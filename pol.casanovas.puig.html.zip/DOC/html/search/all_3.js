var searchData=
[
  ['get_5falf_0',['get_alf',['../class_missatges.html#aab5b28466d0cb7c449a03b4e5f353c94',1,'Missatges']]],
  ['get_5fmsg_1',['get_msg',['../class_missatges.html#a82c4ac7683df7f5384f2d4b457210c3b',1,'Missatges']]]
];
