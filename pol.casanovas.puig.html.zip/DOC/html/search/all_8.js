var searchData=
[
  ['read_5falfabets_0',['read_alfabets',['../class_alfabets.html#a954309d489a7848e122e031a94ab7676',1,'Alfabets']]],
  ['read_5fmissatges_1',['read_missatges',['../class_missatges.html#a029ff77ff8e6e573aa8e1187a817424d',1,'Missatges']]]
];
