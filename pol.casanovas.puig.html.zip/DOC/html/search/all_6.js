var searchData=
[
  ['n_5falf_0',['n_alf',['../class_alfabets.html#abdc00e61db168210327a92655952d024',1,'Alfabets']]],
  ['n_5fmsg_1',['n_msg',['../class_missatges.html#a320ac868fb92eb5d21abcf794087e575',1,'Missatges']]],
  ['n_5fof_5fmsg_2',['n_of_msg',['../class_alfabets.html#ab6f64cefbafa7aaf9deef36aab6a9cd2',1,'Alfabets']]]
];
