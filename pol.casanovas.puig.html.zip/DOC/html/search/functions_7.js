var searchData=
[
  ['print_5falfabets_0',['print_alfabets',['../class_alfabets.html#a42e1b50766116ae09bdb5a6190467ccb',1,'Alfabets']]],
  ['print_5fmissatges_1',['print_missatges',['../class_missatges.html#a1cb6dc974816b3a77656921f16aea6e2',1,'Missatges']]]
];
