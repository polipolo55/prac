var searchData=
[
  ['missatges_0',['Missatges',['../class_missatges.html',1,'']]]
];
