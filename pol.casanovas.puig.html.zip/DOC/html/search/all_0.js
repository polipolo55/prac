var searchData=
[
  ['add_5falf_0',['add_alf',['../class_alfabets.html#a1df46a0f6d6a41ea7a2bf07f38fe80f2',1,'Alfabets']]],
  ['add_5fmsg_1',['add_msg',['../class_missatges.html#afa398edd414f947c17bb8f04f8ae6418',1,'Missatges']]],
  ['alfabets_2',['Alfabets',['../class_alfabets.html',1,'Alfabets'],['../class_alfabets.html#a09f8be470d295c9d06fffa3f8e9495e4',1,'Alfabets::Alfabets()']]],
  ['alfabets_2ehh_3',['Alfabets.hh',['../_alfabets_8hh.html',1,'']]]
];
