var searchData=
[
  ['is_5falf_5fthere_0',['is_alf_there',['../class_alfabets.html#aea12b508e72204de947f2c69c5d34966',1,'Alfabets']]],
  ['is_5fmsg_5fthere_1',['is_msg_there',['../class_missatges.html#aada8db97054291c1eefb169c2d9a4ff6',1,'Missatges']]]
];
