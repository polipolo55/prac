var searchData=
[
  ['del_5falf_0',['del_alf',['../class_alfabets.html#a2906b43a1665ccd0af408d943f46c523',1,'Alfabets']]],
  ['del_5fmsg_1',['del_msg',['../class_missatges.html#acb744dbfcb5a19975757061102062788',1,'Missatges']]]
];
